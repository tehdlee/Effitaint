package com.favorites.domain.enums;

public enum IsDelete {

	YES, NO
}
